import paho.mqtt.client as mqtt
import serial
import time

# Configuración del broker MQTT
broker = "192.168.18.162"
port = 1883
topic = "petfeeder"

# Configuración del puerto serial
serial_port = "COM7"  # Cambia esto por el puerto correcto
baud_rate = 9600  # Cambiado a 9600 baudios

# Conectar al puerto serial
try:
    arduino = serial.Serial(serial_port, baud_rate, timeout=1)
    time.sleep(2)  # Espera a que el puerto serial esté listo
    print(f"Conectado al puerto serial {serial_port}")
except serial.SerialException as e:
    print(f"Error al conectar al puerto serial: {e}")
    exit()

# Crear una instancia del cliente MQTT
client = mqtt.Client()

# Función de callback cuando se recibe un mensaje
def on_message(client, userdata, message):
    comando = message.payload.decode().strip()
    print(f"Received message '{comando}' on topic '{message.topic}'")
    if comando == "ON" or comando == "OFF":
        try:
            arduino.write((comando + '\n').encode())
            print(f"Enviado comando '{comando}' al Arduino")
        except serial.SerialException as e:
            print(f"Error al enviar comando al Arduino: {e}")

# Configurar el cliente
client.on_message = on_message

# Conectar al broker
client.connect(broker, port, 60)

# Suscribirse al tópico de control del motor
client.subscribe(topic)

# Iniciar el loop de red en un hilo separado para manejar mensajes entrantes
client.loop_start()

try:
    while True:
        time.sleep(1)  # Mantén el script ejecutándose
except KeyboardInterrupt:
    print("Desconectando...")
    client.loop_stop()
    client.disconnect()
    arduino.close()
    print("Desconectado del broker MQTT y del puerto serial")
