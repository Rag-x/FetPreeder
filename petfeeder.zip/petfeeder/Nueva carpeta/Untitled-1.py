import serial
import time

# Configura el puerto serie y la velocidad de baudios
ser = serial.Serial('COM3', 9600)  # Reemplaza 'COM3' con el puerto serie correcto

def send_command(command):
    ser.write(command.encode())
    print(f"Comando '{command}' enviado")

try:
    while True:
        user_input = input("Ingresa 'ON' para encender o 'OFF' para apagar: ").strip().upper()
        if user_input == "ON":
            send_command("MOTOR_ON\n")
        elif user_input == "OFF":
            send_command("MOTOR_OFF\n")
        else:
            print("Comando no reconocido. Intenta nuevamente.")
        time.sleep(1)  # Espera un segundo antes de permitir otro comando

except KeyboardInterrupt:
    print("Programa terminado")
finally:
    ser.close()
