import paho.mqtt.client as mqtt
import time
import serial

# Configuración del cliente MQTT
mqtt_broker = "localhost"  # Cambia esto por la dirección IP de tu broker MQTT
mqtt_port = 1883
mqtt_topic_data_comida = "sensors/comida"  # Tema para publicar datos de comida
mqtt_topic_data_agua = "sensors/agua"  # Tema para publicar datos de agua
mqtt_topic_commands = "commands/arduino"  # Tema para recibir comandos

# Configuración del puerto serial
serial_port = "/dev/ttyACM0"  # Cambia esto si tu puerto serial es diferente
baud_rate = 9600

# Crear el cliente MQTT
client = mqtt.Client()

def on_connect(client, userdata, flags, rc):
    print(f"Conectado con código de resultado {rc}")
    # Suscribirse a los temas de comandos
    client.subscribe(mqtt_topic_commands)

def on_message(client, userdata, msg):
    if msg.topic == mqtt_topic_commands:
        command = msg.payload.decode('utf-8')
        print(f"Comando recibido: {command}")
        if command:
            # Enviar el comando al puerto serial
            ser.write((command + '\n').encode())

client.on_connect = on_connect
client.on_message = on_message
client.connect(mqtt_broker, mqtt_port, 60)

client.loop_start()

# Configuración del puerto serial
ser = serial.Serial(serial_port, baud_rate)

try:
    while True:
        # Leer datos del puerto serial
        if ser.in_waiting > 0:
            data = ser.readline().decode('utf-8').strip()
            
            # Procesar los datos
            if data:
                # Asumimos que los datos están en el formato "agua,comida"
                distance_water, distance_food = data.split(',')
                
                # Publicar los datos en el broker MQTT
                mqtt_message_water = f"{distance_water}"
                mqtt_message_food = f"{distance_food}"
                client.publish(mqtt_topic_data_agua, mqtt_message_water)
                client.publish(mqtt_topic_data_comida, mqtt_message_food)
                
                print(f"Datos enviados: Agua = {mqtt_message_water}, Comida = {mqtt_message_food}")
        
        time.sleep(1)

except KeyboardInterrupt:
    print("Programa terminado")

finally:
    ser.close()
    client.loop_stop()
    client.disconnect()